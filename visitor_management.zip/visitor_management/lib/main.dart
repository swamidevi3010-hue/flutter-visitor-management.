import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => VisitorProvider()..loadVisitors(),
      child: const VisitorApp(),
    ),
  );
}

/// Set this to the base URL of your persistent MockAPI resource.
/// Example: https://YOUR_PROJECT.mockapi.io/api/v1
const String mockApiBaseUrl = 'https://6ae37ef5933120ae20f8d81a.mockapi.io';
class Visitor {
  final String id;
  final String name;
  final String mobile;
  final String? email;
  final String visitorType;
  final String project;
  final String purpose;
  final String status;
  final String createdAt;
  final String? checkInTime;
  final String? checkOutTime;

  const Visitor({
    required this.id,
    required this.name,
    required this.mobile,
    this.email,
    required this.visitorType,
    required this.project,
    required this.purpose,
    required this.status,
    required this.createdAt,
    this.checkInTime,
    this.checkOutTime,
  });

  factory Visitor.fromJson(Map<String, dynamic> json) {
    return Visitor(
      id: '${json['id'] ?? ''}',
      name: '${json['visitorname'] ?? ''}',
      mobile: '${json['mobilenumber'] ?? ''}',
      email: json['email']?.toString(),
      visitorType: '${json['vistiortype'] ?? 'Other'}',
      project: '${json['project'] ?? 'Project A'}',
      purpose: '${json['purposeofvisit'] ?? ''}',
      status: '${json['status'] ?? 'Registered'}',
      createdAt:
          '${json['created_at'] ?? DateTime.now().toIso8601String()}',
      checkInTime: json['check_in_time']?.toString(),
      checkOutTime: json['check_out_time']?.toString(),
    );
  }

  Map<String, dynamic> toJson({bool includeId = false}) {
    return {
      if (includeId) 'id': id,
      'visitorname': name,
      'mobilenumber': mobile,
      'email': email,
      'vistiortype': visitorType,
      'project': project,
      'purposeofvisit': purpose,
      'status': status,
      'created_at': createdAt,
      'check_in_time': checkInTime,
      'check_out_time': checkOutTime,
    };
  }

  Visitor copyWith({
    String? name,
    String? mobile,
    String? email,
    String? visitorType,
    String? project,
    String? purpose,
    String? status,
    String? checkInTime,
    String? checkOutTime,
  }) {
    return Visitor(
      id: id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      email: email ?? this.email,
      visitorType: visitorType ?? this.visitorType,
      project: project ?? this.project,
      purpose: purpose ?? this.purpose,
      status: status ?? this.status,
      createdAt: createdAt,
      checkInTime: checkInTime ?? this.checkInTime,
      checkOutTime: checkOutTime ?? this.checkOutTime,
    );
  }
}
class VisitorApi {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl:
          'https://6ae37ef5933120ae20f8d81a.mockapi.io',
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
    ),
  );

  // Your configured MockAPI resource is /Vistiors.
  // Keep this spelling unless you rename the resource in MockAPI.
  static const String endpoint = '/Vistiors';

  Future<List<Visitor>> getVisitors() async {
    final response = await _dio.get(endpoint);

    if (response.data is! List) {
      throw Exception(
        'Unexpected API response: ${response.data}',
      );
    }

    return (response.data as List)
        .map(
          (item) => Visitor.fromJson(
            Map<String, dynamic>.from(item as Map),
          ),
        )
        .toList();
  }

  Future<Visitor> getVisitor(String id) async {
    final response = await _dio.get('$endpoint/$id');

    return Visitor.fromJson(
      Map<String, dynamic>.from(response.data),
    );
  }

  Future<Visitor> createVisitor(Visitor visitor) async {
    final payload = {
      'visitorname': visitor.name,
      'mobilenumber': visitor.mobile,
      'email': visitor.email ?? '',
      'purposeofvisit': visitor.purpose,
      'vistiortype': visitor.visitorType,

      // These additional fields support your app's features.
      'project': visitor.project,
      'status': 'Registered',
      'created_at': DateTime.now().toIso8601String(),
      'check_in_time': null,
      'check_out_time': null,
    };

    try {
      final response = await _dio.post(
        endpoint,
        data: payload,
      );

      return Visitor.fromJson(
        Map<String, dynamic>.from(response.data),
      );
    } on DioException catch (e) {
      debugPrint('POST URL: ${e.requestOptions.uri}');
      debugPrint('POST data: ${e.requestOptions.data}');
      debugPrint('API status: ${e.response?.statusCode}');
      debugPrint('API response: ${e.response?.data}');
      rethrow;
    }
  }

  Future<Visitor> updateVisitor(Visitor visitor) async {
    final response = await _dio.put(
      '$endpoint/${visitor.id}',
      data: visitor.toJson(),
    );

    return Visitor.fromJson(
      Map<String, dynamic>.from(response.data),
    );
  }

  Future<void> deleteVisitor(String id) async {
    await _dio.delete('$endpoint/$id');
  }
}
class VisitorProvider extends ChangeNotifier {
  final VisitorApi _api = VisitorApi();
  List<Visitor> _visitors = [];
  bool isLoading = false;
  String? error;

  List<Visitor> get visitors => List.unmodifiable(_visitors);

  Future<void> loadVisitors() async {
    isLoading = true;
    error = null;
    notifyListeners();
    try {
      _visitors = await _api.getVisitors();
    } catch (e) {
      error = _friendlyError(e);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  String _friendlyError(Object e) {
    if (e is DioException) {
      if (e.response != null) return 'API error (${e.response!.statusCode}). Check your API URL and response.';
      return 'Network error. Check your internet connection.';
    }
    return e.toString().replaceFirst('Exception: ', '');
  }

  List<Visitor> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return visitors;
    return _visitors.where((v) =>
      v.name.toLowerCase().contains(q) || v.mobile.contains(q)).toList();
  }

  int get totalToday => _visitors.where((v) => _isToday(v.createdAt)).length;
  int get checkedIn => _visitors.where((v) => v.status == 'Checked In').length;
  int get checkedOutToday => _visitors.where((v) =>
      v.status == 'Checked Out' &&
      v.checkOutTime != null &&
      _isToday(v.checkOutTime!)).length;

  bool _isToday(String value) {
    final date = DateTime.tryParse(value)?.toLocal();
    final now = DateTime.now();
    return date != null && date.year == now.year &&
        date.month == now.month && date.day == now.day;
  }

  Future<Visitor> create(Visitor visitor) async {
    final created = await _api.createVisitor(visitor);
    _visitors.insert(0, created);
    notifyListeners();
    return created;
  }

  Future<void> update(Visitor visitor) async {
    final updated = await _api.updateVisitor(visitor);
    final index = _visitors.indexWhere((v) => v.id == updated.id);
    if (index >= 0) _visitors[index] = updated;
    else _visitors.insert(0, updated);
    notifyListeners();
  }

  Future<void> delete(String id) async {
    await _api.deleteVisitor(id);
    _visitors.removeWhere((v) => v.id == id);
    notifyListeners();
  }

  Future<Visitor> findById(String id) async {
    final local = _visitors.where((v) => v.id == id);
    if (local.isNotEmpty) return local.first;
    final found = await _api.getVisitor(id);
    _visitors.insert(0, found);
    notifyListeners();
    return found;
  }

  Future<Visitor> checkIn(Visitor visitor) async {
    if (visitor.status != 'Registered') {
      throw Exception('Only Registered visitors can check in.');
    }
    final updated = visitor.copyWith(
      status: 'Checked In',
      checkInTime: DateTime.now().toIso8601String(),
    );
    await update(updated);
    return _visitors.firstWhere((v) => v.id == updated.id);
  }

  Future<Visitor> checkOut(Visitor visitor) async {
    if (visitor.status != 'Checked In') {
      throw Exception('Only Checked In visitors can check out.');
    }
    final updated = visitor.copyWith(
      status: 'Checked Out',
      checkOutTime: DateTime.now().toIso8601String(),
    );
    await update(updated);
    return _visitors.firstWhere((v) => v.id == updated.id);
  }
}

class VisitorApp extends StatelessWidget {
  const VisitorApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Visitor Management',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2457C5)),
          scaffoldBackgroundColor: const Color(0xFFF5F7FB),
          cardTheme: const CardThemeData(
            elevation: 1,
            margin: EdgeInsets.symmetric(vertical: 6),
          ),
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(onNavigate: (i) => setState(() => selectedIndex = i)),
      const VisitorListScreen(),
      const ScannerScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: selectedIndex, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (i) => setState(() => selectedIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Visitors'),
          NavigationDestination(icon: Icon(Icons.qr_code_scanner), label: 'Scan'),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const DashboardScreen({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<VisitorProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Visitor Management'), actions: [
        IconButton(onPressed: p.loadVisitors, icon: const Icon(Icons.refresh)),
      ]),
      body: RefreshIndicator(
        onRefresh: p.loadVisitors,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Good day 👋', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('Front desk overview'),
          const SizedBox(height: 16),
          if (p.error != null)
            Card(child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.error!, style: const TextStyle(color: Colors.red)),
                TextButton(onPressed: p.loadVisitors, child: const Text('Retry')),
              ]),
            )),
          if (p.isLoading && p.visitors.isEmpty)
            const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator())),
          Row(children: [
            Expanded(child: StatCard(title: 'Visitors Today', value: '${p.totalToday}', icon: Icons.people, color: Colors.blue)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(title: 'Checked In', value: '${p.checkedIn}', icon: Icons.login, color: Colors.green)),
          ]),
          StatCard(title: 'Checked Out Today', value: '${p.checkedOutToday}', icon: Icons.logout, color: Colors.orange),
          const SizedBox(height: 16),
          SizedBox(height: 52, child: ElevatedButton.icon(
            onPressed: () async {
              final result = await Navigator.push(context, MaterialPageRoute(builder: (_) => const VisitorFormScreen()));
              if (result == true && context.mounted) context.read<VisitorProvider>().loadVisitors();
            },
            icon: const Icon(Icons.person_add_alt_1), label: const Text('Register Visitor'),
          )),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: () => onNavigate(1), icon: const Icon(Icons.list_alt), label: const Text('View Visitor List')),
          OutlinedButton.icon(onPressed: () => onNavigate(2), icon: const Icon(Icons.qr_code_scanner), label: const Text('Scan QR Code')),
          const SizedBox(height: 12),
          const Text('Recent Visitors', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ...p.visitors.take(4).map((v) => VisitorTile(visitor: v, onTap: () => openDetails(context, v))),
        ]),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  const StatCard({super.key, required this.title, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(16),
    child: Row(children: [
      CircleAvatar(backgroundColor: color.withValues(alpha: .12), child: Icon(icon, color: color)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(fontSize: 12)),
      ])),
    ]),
  ));
}

class VisitorListScreen extends StatefulWidget {
  const VisitorListScreen({super.key});
  @override
  State<VisitorListScreen> createState() => _VisitorListScreenState();
}

class _VisitorListScreenState extends State<VisitorListScreen> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final p = context.watch<VisitorProvider>();
    final list = p.search(query);
    return Scaffold(
      appBar: AppBar(title: const Text('Visitors'), actions: [
        IconButton(onPressed: p.loadVisitors, icon: const Icon(Icons.refresh)),
        IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VisitorFormScreen())), icon: const Icon(Icons.add)),
      ]),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(
          onChanged: (v) => setState(() => query = v),
          decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search by name or mobile', border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
        )),
        if (p.error != null) Padding(padding: const EdgeInsets.all(12), child: Text(p.error!, style: const TextStyle(color: Colors.red))),
        Expanded(child: p.isLoading && p.visitors.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : list.isEmpty
            ? const EmptyState()
            : RefreshIndicator(onRefresh: p.loadVisitors, child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: list.length,
                itemBuilder: (_, i) => VisitorTile(visitor: list[i], onTap: () => openDetails(context, list[i]),
                  trailing: PopupMenuButton<String>(
                    onSelected: (action) async {
                      if (action == 'edit') {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => VisitorFormScreen(visitor: list[i])));
                      } else if (action == 'delete') {
                        final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                          title: const Text('Delete visitor?'),
                          content: Text('Delete ${list[i].name}? This cannot be undone.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                          ],
                        ));
                        if (yes == true && context.mounted) {
                          try { await context.read<VisitorProvider>().delete(list[i].id); }
                          catch (e) { if (context.mounted) showMessage(context, e.toString()); }
                        }
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              )),
        ),
      ]),
    );
  }
}

class VisitorTile extends StatelessWidget {
  final Visitor visitor;
  final VoidCallback onTap;
  final Widget? trailing;
  const VisitorTile({super.key, required this.visitor, required this.onTap, this.trailing});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      onTap: onTap,
      leading: CircleAvatar(child: Text(visitor.name.isEmpty ? '?' : visitor.name[0].toUpperCase())),
      title: Text(visitor.name, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text('${visitor.mobile}\n${visitor.project} • ${visitor.visitorType}'),
      isThreeLine: true,
      trailing: trailing ?? StatusChip(status: visitor.status),
    ),
  );
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip({super.key, required this.status});
  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      'Checked In' => Colors.green,
      'Checked Out' => Colors.blue,
      _ => Colors.orange,
    };
    return Chip(label: Text(status, style: TextStyle(color: color, fontSize: 11)), backgroundColor: color.withValues(alpha: .10), side: BorderSide.none, visualDensity: VisualDensity.compact);
  }
}

class VisitorFormScreen extends StatefulWidget {
  final Visitor? visitor;
  const VisitorFormScreen({super.key, this.visitor});
  @override
  State<VisitorFormScreen> createState() => _VisitorFormScreenState();
}

class _VisitorFormScreenState extends State<VisitorFormScreen> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final mobile = TextEditingController();
  final email = TextEditingController();
  final purpose = TextEditingController();
  String type = 'Customer';
  String project = 'Project A';
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final v = widget.visitor;
    if (v != null) {
      name.text = v.name; mobile.text = v.mobile; email.text = v.email ?? '';
      purpose.text = v.purpose; type = v.visitorType; project = v.project;
    }
  }
  @override
  void dispose() {
    name.dispose(); mobile.dispose(); email.dispose(); purpose.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.visitor == null ? 'Register Visitor' : 'Edit Visitor')),
    body: Form(
      key: formKey,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Visitor information', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        TextFormField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Visitor Name *', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Visitor name is required' : null),
        const SizedBox(height: 12),
        TextFormField(controller: mobile, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: 'Mobile Number *', border: OutlineInputBorder(), counterText: ''), validator: (v) => v == null || !RegExp(r'^[0-9]{10}$').hasMatch(v) ? 'Enter exactly 10 digits' : null),
        const SizedBox(height: 12),
        TextFormField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email (optional)', border: OutlineInputBorder()), validator: (v) => v != null && v.trim().isNotEmpty && !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim()) ? 'Enter a valid email address' : null),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Visitor Type', border: OutlineInputBorder()), items: ['Customer', 'Vendor', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => type = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: project, decoration: const InputDecoration(labelText: 'Project', border: OutlineInputBorder()), items: ['Project A', 'Project B', 'Project C'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => project = v!)),
        const SizedBox(height: 12),
        TextFormField(controller: purpose, maxLines: 3, decoration: const InputDecoration(labelText: 'Purpose of Visit *', border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Purpose is required' : null),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: saving ? null : save, icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save), label: Text(saving ? 'Saving...' : 'Save Visitor')),
        OutlinedButton(onPressed: saving ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
      ]),
    ),
  );

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      final old = widget.visitor;
      final value = Visitor(
        id: old?.id ?? '',
        name: name.text.trim(),
        mobile: mobile.text.trim(),
        email: email.text.trim().isEmpty ? null : email.text.trim(),
        visitorType: type, project: project, purpose: purpose.text.trim(),
        status: old?.status ?? 'Registered',
        createdAt: old?.createdAt ?? DateTime.now().toIso8601String(),
        checkInTime: old?.checkInTime, checkOutTime: old?.checkOutTime,
      );
      if (old == null) {
        final created = await context.read<VisitorProvider>().create(value);
        if (!mounted) return;
        showMessage(context, 'Visitor registered. QR ID: ${created.id}');
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => VisitorDetailsScreen(visitorId: created.id)));
      } else {
        await context.read<VisitorProvider>().update(value);
        if (!mounted) return;
        showMessage(context, 'Visitor updated successfully');
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) showMessage(context, e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }
}

class VisitorDetailsScreen extends StatelessWidget {
  final String visitorId;
  const VisitorDetailsScreen({super.key, required this.visitorId});
  @override
  Widget build(BuildContext context) {
    final p = context.watch<VisitorProvider>();
    final matches = p.visitors.where((v) => v.id == visitorId);
    if (matches.isEmpty) return Scaffold(appBar: AppBar(title: const Text('Visitor Details')), body: const Center(child: CircularProgressIndicator()));
    final visitor = matches.first;
    return Scaffold(
      appBar: AppBar(title: const Text('Visitor Details'), actions: [
        IconButton(icon: const Icon(Icons.edit), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VisitorFormScreen(visitor: visitor)))),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: CircleAvatar(radius: 32, child: Text(visitor.name.isEmpty ? '?' : visitor.name[0].toUpperCase(), style: const TextStyle(fontSize: 24)))),
          const SizedBox(height: 12),
          Center(child: Text(visitor.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          Center(child: StatusChip(status: visitor.status)),
          const Divider(height: 28),
          detailRow('Visitor ID', visitor.id),
          detailRow('Mobile', visitor.mobile),
          detailRow('Email', visitor.email ?? 'Not provided'),
          detailRow('Type', visitor.visitorType),
          detailRow('Project', visitor.project),
          detailRow('Purpose', visitor.purpose),
          detailRow('Registered', formatDate(visitor.createdAt)),
          detailRow('Check-in', formatDate(visitor.checkInTime)),
          detailRow('Check-out', formatDate(visitor.checkOutTime)),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          const Text('Visitor QR Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          QrImageView(data: visitor.id, version: QrVersions.auto, size: 190),
          Text(visitor.id, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]))),
        if (visitor.status == 'Registered')
          FilledButton.icon(onPressed: () => performAction(context, () => p.checkIn(visitor)), icon: const Icon(Icons.login), label: const Text('Check In')),
        if (visitor.status == 'Checked In')
          FilledButton.icon(onPressed: () => performAction(context, () => p.checkOut(visitor)), icon: const Icon(Icons.logout), label: const Text('Check Out')),
        if (visitor.status == 'Checked Out')
          const Padding(padding: EdgeInsets.all(12), child: Center(child: Text('This visit is complete.'))),
      ]),
    );
  }
}

Widget detailRow(String label, String value) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 5),
  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    SizedBox(width: 105, child: Text(label, style: const TextStyle(color: Colors.black54))),
    Expanded(child: Text(value)),
  ]),
);

String formatDate(String? value) {
  if (value == null || value.isEmpty) return '—';
  final date = DateTime.tryParse(value)?.toLocal();
  return date == null ? value : DateFormat('dd MMM yyyy, hh:mm a').format(date);
}

Future<void> performAction(BuildContext context, Future<Visitor> Function() action) async {
  try {
    await action();
    if (context.mounted) showMessage(context, 'Visitor status updated');
  } catch (e) {
    if (context.mounted) showMessage(context, e.toString());
  }
}

Future<void> openDetails(BuildContext context, Visitor visitor) async {
  await Navigator.push(context, MaterialPageRoute(builder: (_) => VisitorDetailsScreen(visitorId: visitor.id)));
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});
  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  bool handled = false;
  bool processing = false;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Scan Visitor QR')),
    body: Column(children: [
      const Padding(padding: EdgeInsets.all(16), child: Text('Place the visitor QR code inside the camera frame.')),
      Expanded(child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: MobileScanner(
          onDetect: (capture) async {
            if (handled || processing || capture.barcodes.isEmpty) return;
            final raw = capture.barcodes.first.rawValue?.trim();
            if (raw == null || raw.isEmpty) return;
            setState(() { processing = true; handled = true; });
            try {
              // The QR payload must be the server-generated visitor ID.
              if (!RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(raw)) {
                throw Exception('Invalid QR code. It must contain a visitor ID.');
              }
              final visitor = await context.read<VisitorProvider>().findById(raw);
              if (!mounted) return;
              await Navigator.push(context, MaterialPageRoute(builder: (_) => VisitorDetailsScreen(visitorId: visitor.id)));
            } catch (e) {
              if (mounted) showMessage(context, 'Visitor not found or invalid QR: $e');
            } finally {
              if (mounted) setState(() { processing = false; handled = false; });
            }
          },
        ),
      )),
      if (processing) const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()),
      Padding(padding: const EdgeInsets.all(16), child: OutlinedButton.icon(
        onPressed: () => setState(() => handled = false),
        icon: const Icon(Icons.refresh), label: const Text('Scan Again'),
      )),
    ]),
  );
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisSize: MainAxisSize.min, children: const [
      Icon(Icons.people_outline, size: 56, color: Colors.grey),
      SizedBox(height: 12),
      Text('No visitors found', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
      Text('Register a visitor or change your search.'),
    ]),
  ));
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
